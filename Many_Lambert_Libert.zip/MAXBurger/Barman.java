public class Barman extends Personnel {

    Barman(String nom, String prenom) {
        super(nom, prenom);
    }
    
}
