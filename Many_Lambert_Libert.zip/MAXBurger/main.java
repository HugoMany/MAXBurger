
public class main {
	
	public static void main(String[] args) {
		Application Resto = new Application();
		Resto.startApp();


		//Addition hello = new Addition();
		//hello.enregistrementFichier();
		//hello.editionFichier();

		// Facture hello = new Facture();
		// hello.lectureFichier();
		// hello.affichageMenuStatsTickets();
		// hello.editionFactureJournaliere();

		// Addition hello = new Addition();
		// hello.testEdition2(2,3);


	}

}
