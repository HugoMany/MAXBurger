public class Cuisinier extends Personnel {

    Cuisinier(String nom, String prenom) {
        super(nom, prenom);
    }
    
}
