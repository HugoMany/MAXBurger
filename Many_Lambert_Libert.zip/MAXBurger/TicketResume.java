public class TicketResume {
    
    protected int numTable;
    protected int numCommande;
    protected Double montantPaye;

    public TicketResume(int numTable, int numCommande, Double montantPaye) {
        this.numTable = numTable;
        this.numTable = numTable;
        this.montantPaye = montantPaye;
    }

}
